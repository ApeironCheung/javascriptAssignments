function p01Func() {
	

  document.getElementById("problem").innerHTML="<p>Basketball is a team sport in which two teams, most commonly of five players each, opposing one another on a rectangular court, compete with the primary objective of shooting a basketball (approximately 9.4 inches (24 cm) in diameter) through the defender's hoop</p>"

  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;

  /* in Ex3, update display of images */
  document.getElementById("flowchart").setAttribute("src","images/basketball/basketball_design.jpg");
  document.getElementById("flowchart").setAttribute("display","none");
  document.getElementById("js").setAttribute("src","images/basketball/basketball_js.jpg");
}


/* in Ex2, uncomment the following function and complete it*/

/* remove this line
function checkUncheck1(){
  if (document.getElementById("check1").checked==true) {
     // add a getElementById here to get "flowchart" img and 
     // set the display property of its style to one of "inline" or "none"	 

	 
  }
  else {
     // add a getElementById here to get "flowchart" img and 
     // set the display property of its style to one of "inline" or "none"	 
	  
	  
  }
}
remove this line */

/* remove this line
function checkUncheck2(){
  if (document.getElementById("check2").checked==true) {
     // add a getElementById here to get "js" img and 
     // set the display property of its style  
	 
	 
  }
  else {
     // add a getElementById here to get "js" img and 
     // set the display property of its style  
	  
	  
  }
}
remove this line */

/* in Ex2, you need to create function
   checkUncheck3, which is similar to checkUncheck 1 and 2
*/



/* in Ex3, create function p02Func similar to p01Func */

/* in Ex4, create functions zoomIn() and zoomOut() */
